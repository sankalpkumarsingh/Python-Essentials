#!/usr/bin/env python
# coding: utf-8

# In[20]:


#STRING
name= "sankalp23"
name


# In[21]:


name.capitalize()


# In[22]:


name.upper()


# In[23]:


name.isalnum()


# In[24]:


name.isalpha()


# In[28]:


name.find("a")


# In[29]:


name.count("s")


# In[33]:


name.split("s")


# In[34]:


name.istitle()


# In[38]:


name.format()


# In[39]:


name.replace("s","a")


# In[ ]:




