#!/usr/bin/env python
# coding: utf-8

# In[34]:


#LIST AND DEFAULT FUNCTIONS
li =  [22,3444,55,55,2.67,556781]

print(li)


# In[4]:


li.append(45)


# In[5]:


print(li)


# In[6]:


li.clear()
print(li)


# In[41]:


li = ["Lets upgrade","python",7865,9900]
print(li)


# In[42]:


li.count("python")


# In[45]:


li2=li.copy()
print(li2)
li2.append(34)
    
print(li2)


# In[46]:


li.extend(["program"])
print(li)


# In[52]:


print(li.index("python"))


# In[57]:


li.insert(0,"java")
print(li)


# In[58]:


li.pop(0)
print(li)


# In[62]:


li.remove(9900)
print(li)


# In[63]:


li.reverse()
print(li)


# In[ ]:




