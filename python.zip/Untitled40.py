#!/usr/bin/env python
# coding: utf-8

# In[22]:


#DICTIONARY AND DEFAULT FUNCTION
dit = {"name" :"sankalp", "phone" : 342233, "Email" : "sankalprajput251@gmail.com"}
dit


# In[23]:


dit.get('name')


# In[24]:


dit.items()


# In[25]:


dit.keys()


# In[26]:


dit.pop('phone')


# In[27]:


dit.pop('name')


# In[28]:


dit


# In[29]:


dit[1]="python"
dit


# In[ ]:




