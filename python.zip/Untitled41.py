#!/usr/bin/env python
# coding: utf-8

# In[1]:


#SETS
sts = { "Lets" ,"Upgrade" , 32345,876}
sts


# In[5]:


sts1 = {}
sts1.issubset(sts)


# In[6]:


sts.add(4)
sts


# In[8]:


sts.update([222,333])
sts


# In[13]:


A = {1,2,3,4,5}
B= {6,7,8,9,10}
A.union(B)
B.union(A)


# In[15]:


sts.pop()


# In[16]:


sts


# In[17]:


sts.discard(222)
sts


# In[ ]:




