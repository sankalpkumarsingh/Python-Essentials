#!/usr/bin/env python
# coding: utf-8

# In[3]:


#TUPLE
tup = ("Lets upgrade","Lets upgrade","Phone:9110173488")
tup


# In[4]:


tup.count("Lets upgrade")


# In[5]:


tup.index("Lets upgrade")


# In[ ]:




